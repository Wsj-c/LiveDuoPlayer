# Live Duo Player (Android starter project)

This project is a first Android implementation of the two requested controls:
1. Two separate ExoPlayer instances. Pausing/playing source 1 does not stop or reset source 2.
2. Pause uses ExoPlayer's pause state and keeps the PlayerView attached, so the last rendered frame remains visible while paused.

## Important limitation: live pause is not automatically unlimited DVR
For a normal live HLS playlist, the server may remove old segments as the live window advances. When that happens, a player cannot seek back to the old point. Exact long-pause resume requires either:
- a source whose HLS/DASH manifest advertises a sufficiently long DVR/time-shift window, or
- a local continuous recorder/time-shift store that writes incoming segments to disk and serves them back to the player.

This starter does NOT yet implement the local DVR recorder, so it must not be represented as satisfying unlimited pause for every live URL.

## Build
Open this folder in Android Studio (Hedgehog or newer), allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).
Requires Android SDK 35 and JDK 17.

## Supported input
Media3 handles common HTTP(S) media URLs and HLS (.m3u8) when the stream is compatible. A playlist file (M3U) is a channel list, not itself necessarily a playable stream URL; paste an individual channel URL.
