package com.example.liveduo

import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class MainActivity : AppCompatActivity() {
    private lateinit var player1: ExoPlayer
    private lateinit var player2: ExoPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Each player is independent. Do not request audio focus, so starting one
        // does not automatically pause the other due to this app's own focus request.
        val audioAttrs = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()

        player1 = ExoPlayer.Builder(this).build().apply {
            setAudioAttributes(audioAttrs, false)
            addListener(errorListener("播放器 1"))
        }
        player2 = ExoPlayer.Builder(this).build().apply {
            setAudioAttributes(audioAttrs, false)
            addListener(errorListener("播放器 2"))
        }

        findViewById<PlayerView>(R.id.playerView1).player = player1
        findViewById<PlayerView>(R.id.playerView2).player = player2

        val url1 = findViewById<EditText>(R.id.url1)
        val url2 = findViewById<EditText>(R.id.url2)

        findViewById<Button>(R.id.load1).setOnClickListener { load(player1, url1.text.toString(), "播放器 1") }
        findViewById<Button>(R.id.load2).setOnClickListener { load(player2, url2.text.toString(), "播放器 2") }
        findViewById<Button>(R.id.play1).setOnClickListener { player1.play() }
        findViewById<Button>(R.id.pause1).setOnClickListener { player1.pause() }
        findViewById<Button>(R.id.play2).setOnClickListener { player2.play() }
        findViewById<Button>(R.id.pause2).setOnClickListener { player2.pause() }
    }

    private fun load(player: ExoPlayer, rawUrl: String, label: String) {
        val value = rawUrl.trim()
        if (value.isEmpty()) {
            Toast.makeText(this, "请先粘贴直播源链接", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val uri = Uri.parse(value)
            val item = MediaItem.fromUri(uri)
            player.setMediaItem(item)
            player.prepare()
            player.playWhenReady = true
        } catch (e: Exception) {
            Toast.makeText(this, "$label：链接格式不正确", Toast.LENGTH_LONG).show()
        }
    }

    private fun errorListener(label: String) = object : Player.Listener {
        override fun onPlayerError(error: PlaybackException) {
            Toast.makeText(this@MainActivity, "$label 播放失败：${error.errorCodeName}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onStop() {
        super.onStop()
        // Keep the two player instances alive while this Activity is stopped.
        // Full lock-screen/background service support is intentionally not claimed in this first build.
    }

    override fun onDestroy() {
        findViewById<PlayerView>(R.id.playerView1).player = null
        findViewById<PlayerView>(R.id.playerView2).player = null
        player1.release()
        player2.release()
        super.onDestroy()
    }
}
